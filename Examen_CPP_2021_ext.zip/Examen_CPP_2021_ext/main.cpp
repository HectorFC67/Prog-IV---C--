#include <iostream>

/* Descomentar una vez creadas las clases creador y usuario
#include "Creador.h"
#include "Usuario.h"
*/

using namespace std;

int main()
{
	/* Descomentar una vez creadas las clases creador y usuario
	Creador* c1 = new Creador("Pablo", 46);
	Creador c2("I�aki", 38);

	Usuario* u1 = new Usuario("Alberto", 25);
	*/

	cout << "�Suerte en el examen!" << endl << endl;

	return 0;
}
